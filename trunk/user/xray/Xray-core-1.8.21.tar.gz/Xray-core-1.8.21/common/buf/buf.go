// Package buf provides a light-weight memory allocation mechanism.
package buf // import "github.com/xtls/xray-core/common/buf"

//go:generate go run github.com/xtls/xray-core/common/errors/errorgen
