// Package app contains feature implementations of Xray. The features may be enabled during runtime.
package app
