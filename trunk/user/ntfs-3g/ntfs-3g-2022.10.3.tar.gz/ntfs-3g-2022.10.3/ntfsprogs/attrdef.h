#ifndef _NTFS_ATTRDEF_H_
#define _NTFS_ATTRDEF_H_

extern const unsigned char attrdef_ntfs3x_array[2560];

#endif /* _NTFS_ATTRDEF_H_ */

