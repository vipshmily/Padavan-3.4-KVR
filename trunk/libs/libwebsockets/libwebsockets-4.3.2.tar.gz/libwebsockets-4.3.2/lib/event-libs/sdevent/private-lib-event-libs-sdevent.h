#include <private-lib-core.h>

extern const struct lws_event_loop_ops event_loop_ops_sdevent;
